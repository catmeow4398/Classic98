#include "Commands.h"
#include "Chat.h"
#include "String_.h"
#include "Event.h"
#include "Game.h"
#include "Logger.h"
#include "Server.h"
#include "World.h"
#include "Inventory.h"
#include "Entity.h"
#include "Window.h"
#include "Graphics.h"
#include "Funcs.h"
#include "Block.h"
#include "EnvRenderer.h"
#include "Utils.h"
#include "TexturePack.h"
#include "Options.h"
#include "Drawer2D.h"
#include "Audio.h"
#include "Platform.h"
#include "Picking.h"
#include "Vectors.h"
#include "ExtMath.h"
#include "Gui.h"
#include "Camera.h"

#define COMMANDS_PREFIX "/client"
#define COMMANDS_PREFIX_SPACE "/client "
static struct ChatCommand* cmds_head;
static struct ChatCommand* cmds_tail;

void Commands_Register(struct ChatCommand* cmd) {
	LinkedList_Append(cmd, cmds_head, cmds_tail);
}

void Commands_Unregister(struct ChatCommand* cmd) {
	struct ChatCommand* cur;
	LinkedList_Remove(cmd, cur, cmds_head, cmds_tail);
}


/*########################################################################################################################*
*------------------------------------------------------Command handling---------------------------------------------------*
*#########################################################################################################################*/
static cc_bool Alias_TryRun(const cc_string* name);

static struct ChatCommand* Commands_FindMatch(const cc_string* cmdName) {
	struct ChatCommand* match = NULL;
	struct ChatCommand* cmd;
	cc_string name;

	for (cmd = cmds_head; cmd; cmd = cmd->next) 
	{
		name = String_FromReadonly(cmd->name);
		if (String_CaselessEquals(&name, cmdName)) return cmd;
	}

	for (cmd = cmds_head; cmd; cmd = cmd->next) 
	{
		name = String_FromReadonly(cmd->name);
		if (!String_CaselessStarts(&name, cmdName)) continue;

		if (match) {
			Chat_Add1("&e/client: Hay varios comandos que empiezan con: \"&f%s&e\".", cmdName);
			return NULL;
		}
		match = cmd;
	}

	if (!match) {
		Chat_Add1("&e/client: Comando desconocido: \"&f%s&e\".", cmdName);
		Chat_AddRaw("&e/client: Escribe &a/client &epara ver la lista de comandos.");
	}
	return match;
}

static void Commands_PrintDefault(void) {
	cc_string str; char strBuffer[STRING_SIZE];
	struct ChatCommand* cmd;
	cc_string name;

	Chat_AddRaw("&eLista de comandos del cliente:");
	String_InitArray(str, strBuffer);

	for (cmd = cmds_head; cmd; cmd = cmd->next) {
		name = String_FromReadonly(cmd->name);

		if ((str.length + name.length + 2) > str.capacity) {
			Chat_Add(&str);
			str.length = 0;
		}
		String_AppendString(&str, &name);
		String_AppendConst(&str, ", ");
	}

	if (str.length) { Chat_Add(&str); }
	Chat_AddRaw("&ePara ver la ayuda de un comando, escribe /client help [comando]");
}

cc_bool Commands_Execute(const cc_string* input) {
	static const cc_string prefixSpace = String_FromConst(COMMANDS_PREFIX_SPACE);
	static const cc_string prefix      = String_FromConst(COMMANDS_PREFIX);
	cc_string text;

	struct ChatCommand* cmd;
	int offset, count;
	cc_string name, value;
	cc_string args[50];

	if (String_CaselessStarts(input, &prefixSpace)) { 
		/* /client [command] [args] */
		offset = prefixSpace.length;
	} else if (String_CaselessEquals(input, &prefix)) { 
		/* /client */
		offset = prefix.length;
	} else if (Server.IsSinglePlayer && String_CaselessStarts(input, &prefix)) {
		/* /client[command] [args] */
		offset = prefix.length;
	} else if (Server.IsSinglePlayer && input->length && input->buffer[0] == '/') {
		/* /[command] [args] */
		offset = 1;
	} else {
		return false;
	}

	text = String_UNSAFE_SubstringAt(input, offset);
	/* Check for only / or /client */
	if (!text.length) { Commands_PrintDefault(); return true; }

	String_UNSAFE_Separate(&text, ' ', &name, &value);
	if (Alias_TryRun(&name)) return true;
	cmd = Commands_FindMatch(&name);
	if (!cmd) return true;

	if ((cmd->flags & COMMAND_FLAG_SINGLEPLAYER_ONLY) && !Server.IsSinglePlayer) {
		Chat_Add1("&e/client: \"&f%s&e\" solo se puede usar en un jugador.", &name);
		return true;
	}

	if (cmd->flags & COMMAND_FLAG_UNSPLIT_ARGS) {
		/* argsCount = 0 if value.length is 0, 1 otherwise */
		cmd->Execute(&value, value.length != 0);
	} else {
		count = String_UNSAFE_Split(&value, ' ', args, Array_Elems(args));
		cmd->Execute(args,   value.length ? count : 0);
	}
	return true;
}


/*########################################################################################################################*
*------------------------------------------------------Simple commands----------------------------------------------------*
*#########################################################################################################################*/
static void HelpCommand_Execute(const cc_string* args, int argsCount) {
	struct ChatCommand* cmd;
	int i;

	if (!argsCount) { Commands_PrintDefault(); return; }
	cmd = Commands_FindMatch(args);
	if (!cmd) return;

	for (i = 0; i < Array_Elems(cmd->help); i++) {
		if (!cmd->help[i]) continue;
		Chat_AddRaw(cmd->help[i]);
	}
}

static struct ChatCommand HelpCommand = {
	"Help", HelpCommand_Execute,
	COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client help [command name]",
		"&eMuestra la ayuda del comando indicado.",
	}
};

static void GpuInfoCommand_Execute(const cc_string* args, int argsCount) {
	char buffer[7 * STRING_SIZE];
	cc_string str, line;
	String_InitArray(str, buffer);
	Gfx_GetApiInfo(&str);
	
	while (str.length) {
		String_UNSAFE_SplitBy(&str, '\n', &line);
		if (line.length) Chat_Add1("&a%s", &line);
	}
}

static struct ChatCommand GpuInfoCommand = {
	"GpuInfo", GpuInfoCommand_Execute,
	COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client gpuinfo",
		"&eMuestra informacion de tu GPU.",
	}
};

static void RenderTypeCommand_Execute(const cc_string* args, int argsCount) {
	int flags;
	if (!argsCount) {
		Chat_AddRaw("&e/client: &cNo indicaste un nuevo tipo de dibujado."); return;
	}

	flags = EnvRenderer_CalcFlags(args);
	if (flags >= 0) {
		EnvRenderer_SetMode(flags);
		Options_Set(OPT_RENDER_TYPE, args);
		Chat_Add1("&e/client: &fEl tipo de dibujado ahora es %s.", args);
	} else {
		Chat_Add1("&e/client: &cTipo de dibujado desconocido &f\"%s\"&c.", args);
	}
}

static struct ChatCommand RenderTypeCommand = {
	"RenderType", RenderTypeCommand_Execute,
	COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client rendertype [normal/legacy/fast]",
		"&bnormal: &eModo predeterminado, con todos los efectos del entorno",
		"&blegacy: &eIgual que normal, &cpero suele ser algo mas lento",
		"   &eSi las nubes o los bordes del mapa desaparecen al azar, usa este modo",
		"&bfast: &eSacrifica nubes, niebla y cielo para ir mas rapido",
	}
};

static void RetroCommand_Execute(const cc_string* args, int argsCount) {
	cc_bool on;
	if (!argsCount) {
		Chat_Add1("&e/client retro: &fLas texturas retro estan %c&f.", Retro_Enabled ? "&aactivadas" : "&cdesactivadas");
		return;
	}

	if (String_CaselessEqualsConst(&args[0], "level")) {
		int level;
		if (argsCount < 2 || !Convert_ParseInt(&args[1], &level) || level < 1 || level > 3) {
			Chat_Add1("&e/client retro: &fNivel actual: &a%i&f. Usa &a/client retro level [1-3]", &Retro_Level);
			return;
		}
		Retro_Level = level;
		Options_SetInt(OPT_RETRO_LEVEL, level);
		TexturePack_ExtractCurrent(true);
		Chat_Add1("&e/client retro: &fNivel de intensidad ahora es &a%i&f.", &level);
		return;
	}

	if (String_CaselessEqualsConst(&args[0], "on")) {
		on = true;
	} else if (String_CaselessEqualsConst(&args[0], "off")) {
		on = false;
	} else {
		Chat_AddRaw("&e/client retro: &cUsa &f/client retro on &co &f/client retro off&c.");
		return;
	}

	Retro_Enabled = on;
	Options_SetBool(OPT_RETRO, on);
	/* Reloads the current texture pack, so the filter is applied (or removed) */
	TexturePack_ExtractCurrent(true);
	Chat_Add1("&e/client retro: &fLas texturas retro ahora estan %c&f.", on ? "&aactivadas" : "&cdesactivadas");
}

static struct ChatCommand RetroCommand = {
	"Retro", RetroCommand_Execute,
	0,
	{
		"&a/client retro [on/off]  &e/  &a/client retro level [1-3]",
		"&eActiva o desactiva el filtro de texturas retro de los 80.",
		"&eSolo cambia el aspecto de las texturas, nunca las reglas del servidor.",
	}
};

/*########################################################################################################################*
*---------------------------------------------------Classic98 commands----------------------------------------------------*
*#########################################################################################################################*/
static const char* Classic98_Compass(float dx, float dz) {
	float ax = Math_AbsF(dx), az = Math_AbsF(dz);
	/* Convention: -Z is north, +X is east */
	if (ax > az * 2.4f) return dx > 0 ? "este" : "oeste";
	if (az > ax * 2.4f) return dz > 0 ? "sur"  : "norte";
	if (dz < 0) return dx > 0 ? "noreste" : "noroeste";
	return dx > 0 ? "sureste" : "suroeste";
}

/*-------------------------------------------------------- where -----------------------------------------------------------*/
static void WhereCommand_Execute(const cc_string* args, int argsCount) {
	struct Entity* e = &Entities.CurPlayer->Base;
	IVec3 pos;
	Vec3 dir;
	cc_string name;

	IVec3_Floor(&pos, &e->Position);
	Chat_Add3("&eTu posicion: &f%i, %i, %i", &pos.x, &pos.y, &pos.z);

	dir = Vec3_GetDirVector(e->Yaw * MATH_DEG2RAD, e->Pitch * MATH_DEG2RAD);
	Chat_Add1("&eMirando hacia: &f%c", Classic98_Compass(dir.x, dir.z));

	if (Game_SelectedPos.valid) {
		name = Block_UNSAFE_GetName(Game_SelectedPos.block);
		Chat_Add4("&eBloque enfrente: &f%s &7(%i, %i, %i)", &name, &Game_SelectedPos.pos.x, &Game_SelectedPos.pos.y, &Game_SelectedPos.pos.z);
	} else {
		Chat_AddRaw("&eBloque enfrente: &fninguno");
	}
}

static struct ChatCommand WhereCommand = {
	"Where", WhereCommand_Execute,
	0,
	{
		"&a/client where",
		"&eMuestra tus coordenadas, hacia donde miras y el bloque enfrente.",
	}
};

/*------------------------------------------------------- waypoint ---------------------------------------------------------*/
#define WP_MAX 16
#define WP_NAME 24
static char wp_names[WP_MAX][WP_NAME];
static int  wp_x[WP_MAX], wp_y[WP_MAX], wp_z[WP_MAX];
static cc_bool wp_used[WP_MAX], wp_loaded;

static void Waypoint_Save(int i) {
	char key[32], buf[96];
	cc_string k = String_FromArray(key), v = String_FromArray(buf);
	String_Format1(&k, "classic98-wp-%i", &i);
	if (wp_used[i]) {
		String_Format4(&v, "%c,%i,%i,%i", wp_names[i], &wp_x[i], &wp_y[i], &wp_z[i]);
		Options_Set(key, &v);
	} else {
		Options_Set(key, NULL);
	}
}

static void Waypoint_LoadAll(void) {
	int i;
	if (wp_loaded) return;
	wp_loaded = true;

	for (i = 0; i < WP_MAX; i++) {
		char key[32];
		cc_string k = String_FromArray(key), v, parts[4];
		String_Format1(&k, "classic98-wp-%i", &i);
		if (!Options_UNSAFE_Get(key, &v)) continue;
		if (String_UNSAFE_Split(&v, ',', parts, 4) != 4) continue;
		if (!Convert_ParseInt(&parts[1], &wp_x[i]) || !Convert_ParseInt(&parts[2], &wp_y[i]) || !Convert_ParseInt(&parts[3], &wp_z[i])) continue;
		if (parts[0].length == 0 || parts[0].length >= WP_NAME) continue;

		Mem_Copy(wp_names[i], parts[0].buffer, parts[0].length);
		wp_names[i][parts[0].length] = '\0';
		wp_used[i] = true;
	}
}

static int Waypoint_Find(const cc_string* name) {
	int i;
	for (i = 0; i < WP_MAX; i++) {
		cc_string n;
		if (!wp_used[i]) continue;
		n = String_FromReadonly(wp_names[i]);
		if (String_CaselessEquals(&n, name)) return i;
	}
	return -1;
}

static void WaypointCommand_Execute(const cc_string* args, int argsCount) {
	struct Entity* e = &Entities.CurPlayer->Base;
	IVec3 pos;
	int i, count = 0;
	Waypoint_LoadAll();

	if (argsCount >= 2 && String_CaselessEqualsConst(&args[0], "set")) {
		const cc_string* name = &args[1];
		if (name->length >= WP_NAME) { Chat_AddRaw("&e/client waypoint: &cNombre demasiado largo (maximo 23)."); return; }
		if (String_IndexOf(name, ',') >= 0) { Chat_AddRaw("&e/client waypoint: &cEl nombre no puede llevar comas."); return; }

		i = Waypoint_Find(name);
		if (i < 0) {
			for (i = 0; i < WP_MAX && wp_used[i]; i++) { }
			if (i == WP_MAX) { Chat_AddRaw("&e/client waypoint: &cYa tienes 16 puntos, borra alguno."); return; }
		}

		IVec3_Floor(&pos, &e->Position);
		Mem_Copy(wp_names[i], name->buffer, name->length);
		wp_names[i][name->length] = '\0';
		wp_x[i] = pos.x; wp_y[i] = pos.y; wp_z[i] = pos.z;
		wp_used[i] = true;
		Waypoint_Save(i);
		Chat_Add4("&e/client waypoint: &fGuardado &a%c &fen %i, %i, %i", wp_names[i], &pos.x, &pos.y, &pos.z);
		return;
	}

	if (argsCount >= 2 && String_CaselessEqualsConst(&args[0], "remove")) {
		i = Waypoint_Find(&args[1]);
		if (i < 0) { Chat_AddRaw("&e/client waypoint: &cEse punto no existe."); return; }
		wp_used[i] = false;
		Waypoint_Save(i);
		Chat_AddRaw("&e/client waypoint: &fPunto eliminado.");
		return;
	}

	if (argsCount >= 1 && String_CaselessEqualsConst(&args[0], "list")) {
		for (i = 0; i < WP_MAX; i++) {
			float dx, dy, dz;
			int dist;
			if (!wp_used[i]) continue;
			count++;

			dx = wp_x[i] + 0.5f - e->Position.x;
			dy = wp_y[i] - e->Position.y;
			dz = wp_z[i] + 0.5f - e->Position.z;
			dist = (int)Math_SqrtF(dx*dx + dy*dy + dz*dz);
			Chat_Add4("&a%c &7(%i, %i, %i)", wp_names[i], &wp_x[i], &wp_y[i], &wp_z[i]);
			Chat_Add2("   &fa &e%i &fbloques, hacia el &e%c", &dist, Classic98_Compass(dx, dz));
		}
		if (!count) Chat_AddRaw("&e/client waypoint: &fNo tienes puntos guardados.");
		return;
	}

	Chat_AddRaw("&e/client waypoint: &cUsa &fset [nombre]&c, &flist &co &fremove [nombre]&c.");
}

static struct ChatCommand WaypointCommand = {
	"Waypoint", WaypointCommand_Execute,
	0,
	{
		"&a/client waypoint set [nombre]",
		"&a/client waypoint list",
		"&a/client waypoint remove [nombre]",
		"&eGuarda puntos con nombre y muestra distancia y direccion.",
		"&eNo teletransporta. Los puntos son globales, no por mapa.",
	}
};

/*--------------------------------------------------------- fov ------------------------------------------------------------*/
static void FovCommand_Execute(const cc_string* args, int argsCount) {
	int fov;
	if (!argsCount) {
		Chat_Add1("&e/client fov: &fCampo de vision actual: &a%i", &Camera.DefaultFov);
		return;
	}
	if (!Convert_ParseInt(&args[0], &fov) || fov < 30 || fov > 110) {
		Chat_AddRaw("&e/client fov: &cUsa un numero entre 30 y 110.");
		return;
	}
	Camera.DefaultFov = fov;
	Camera_SetFov(fov);
	Options_SetInt(OPT_FIELD_OF_VIEW, fov);
	Chat_Add1("&e/client fov: &fCampo de vision ahora es &a%i&f.", &fov);
}

static struct ChatCommand FovCommand = {
	"Fov", FovCommand_Execute,
	0,
	{
		"&a/client fov [30-110]",
		"&eCambia el campo de vision. Solo afecta la camara.",
	}
};

/*-------------------------------------------------------- clear -----------------------------------------------------------*/
static void ClearCommand_Execute(const cc_string* args, int argsCount) {
	int i;
	/* Pushes old messages out of view. Scrollback and chat logs are not touched. */
	for (i = 0; i < Gui.Chatlines + 1; i++) Chat_AddRaw(" ");
}

static struct ChatCommand ClearCommand = {
	"Clear", ClearCommand_Execute,
	0,
	{
		"&a/client clear",
		"&eLimpia el chat de la pantalla.",
	}
};

/*-------------------------------------------------------- time ------------------------------------------------------------*/
static void TimeCommand_Execute(const cc_string* args, int argsCount) {
	struct cc_datetime now;
	DateTime_CurrentLocal(&now);
	Chat_Add3("&eHora: &f%p2:%p2:%p2", &now.hour, &now.minute, &now.second);
	Chat_Add3("&eFecha: &f%p2/%p2/%p4", &now.day, &now.month, &now.year);
}

static struct ChatCommand TimeCommand = {
	"Time", TimeCommand_Execute,
	0,
	{
		"&a/client time",
		"&eMuestra la hora y la fecha reales de tu dispositivo.",
	}
};

/*-------------------------------------------------------- calc ------------------------------------------------------------*/
static const char* calc_p;
static cc_bool calc_err;
static double Calc_Expr(void);

static void Calc_Skip(void) { while (*calc_p == ' ') calc_p++; }

static double Calc_Atom(void) {
	double v = 0, frac = 0.1;
	cc_bool any = false;
	Calc_Skip();

	if (*calc_p == '(') {
		calc_p++;
		v = Calc_Expr();
		Calc_Skip();
		if (*calc_p != ')') calc_err = true; else calc_p++;
		return v;
	}
	while (*calc_p >= '0' && *calc_p <= '9') { v = v * 10 + (*calc_p - '0'); calc_p++; any = true; }
	if (*calc_p == '.' || *calc_p == ',') {
		calc_p++;
		while (*calc_p >= '0' && *calc_p <= '9') { v += (*calc_p - '0') * frac; frac /= 10; calc_p++; any = true; }
	}
	if (!any) calc_err = true;
	return v;
}

static double Calc_Factor(void) {
	double b, r = 1;
	int n, i;
	Calc_Skip();
	if (*calc_p == '-') { calc_p++; return -Calc_Factor(); }
	if (*calc_p == '+') { calc_p++; return  Calc_Factor(); }

	b = Calc_Atom();
	Calc_Skip();
	if (*calc_p == '^') {
		double e;
		calc_p++;
		e = Calc_Factor();
		n = (int)e;
		if (e != (double)n || n < -64 || n > 64) { calc_err = true; return 0; }
		for (i = 0; i < (n < 0 ? -n : n); i++) r *= b;
		if (n < 0) { if (r == 0) { calc_err = true; return 0; } r = 1 / r; }
		return r;
	}
	return b;
}

static double Calc_Term(void) {
	double v = Calc_Factor();
	for (;;) {
		Calc_Skip();
		if (*calc_p == '*' || *calc_p == 'x') {
			calc_p++; v *= Calc_Factor();
		} else if (*calc_p == '/') {
			double d;
			calc_p++; d = Calc_Factor();
			if (d == 0) { calc_err = true; return 0; }
			v /= d;
		} else if (*calc_p == '%') {
			double d;
			calc_p++; d = Calc_Factor();
			if (d == 0) { calc_err = true; return 0; }
			v = v - d * (double)(long long)(v / d);
		} else return v;
	}
}

static double Calc_Expr(void) {
	double v = Calc_Term();
	for (;;) {
		Calc_Skip();
		if (*calc_p == '+') { calc_p++; v += Calc_Term(); }
		else if (*calc_p == '-') { calc_p++; v -= Calc_Term(); }
		else return v;
	}
}

static void CalcCommand_Execute(const cc_string* args, int argsCount) {
	char expr[STRING_SIZE], out[STRING_SIZE];
	cc_string e = String_FromArray(expr), o = String_FromArray(out);
	double v;
	int i;

	if (!argsCount) { Chat_AddRaw("&e/client calc: &cEscribe una operacion, ej: &f/client calc (2+3)*4"); return; }
	for (i = 0; i < argsCount; i++) String_AppendString(&e, &args[i]);
	expr[e.length] = '\0';

	calc_p = expr; calc_err = false;
	v = Calc_Expr();
	Calc_Skip();
	if (*calc_p != '\0') calc_err = true;
	if (calc_err || v > 1e15 || v < -1e15) {
		Chat_AddRaw("&e/client calc: &cNo pude calcular eso (revisa la operacion).");
		return;
	}

	if (v == (double)(long long)v && v < 2e9 && v > -2e9) {
		String_AppendInt(&o, (int)v);
	} else {
		String_AppendFloat(&o, (float)v, 4);
		while (o.length > 1 && o.buffer[o.length - 1] == '0') o.length--;
		if (o.buffer[o.length - 1] == '.') o.length--;
	}
	Chat_Add2("&e%s = &a%s", &e, &o);
}

static struct ChatCommand CalcCommand = {
	"Calc", CalcCommand_Execute,
	0,
	{
		"&a/client calc [operacion]",
		"&eSuma +, resta -, multiplica * (o x), divide /, resto %, potencia ^",
		"&ey parentesis. Ejemplo: &f/client calc (2+3)*4",
	}
};

/*-------------------------------------------------------- dice ------------------------------------------------------------*/
static RNGState dice_rnd;
static cc_bool dice_seeded;

static void DiceCommand_Execute(const cc_string* args, int argsCount) {
	int sides = 6, roll;
	if (!dice_seeded) { Random_SeedFromCurrentTime(&dice_rnd); dice_seeded = true; }

	if (argsCount && (String_CaselessEqualsConst(&args[0], "coin") || String_CaselessEqualsConst(&args[0], "moneda"))) {
		Chat_Add1("&eMoneda: &a%c", Random_Next(&dice_rnd, 2) ? "cara" : "cruz");
		return;
	}
	if (argsCount && (!Convert_ParseInt(&args[0], &sides) || sides < 2 || sides > 1000)) {
		Chat_AddRaw("&e/client dice: &cUsa un numero de caras entre 2 y 1000, o &fcoin&c.");
		return;
	}
	roll = Random_Next(&dice_rnd, sides) + 1;
	Chat_Add2("&eDado d%i: &a%i", &sides, &roll);
}

static struct ChatCommand DiceCommand = {
	"Dice", DiceCommand_Execute,
	0,
	{
		"&a/client dice [caras]  &e/  &a/client dice coin",
		"&eTira un dado (6 caras por defecto) o una moneda.",
	}
};

/*----------------------------------------------------- crosshair ----------------------------------------------------------*/
static const struct { const char* name; const char* hex; } crosshair_colors[] = {
	{ "white","FFFFFF" }, { "red","FF0000" }, { "green","00FF00" }, { "blue","0080FF" },
	{ "yellow","FFFF00" }, { "cyan","00FFFF" }, { "magenta","FF00FF" }, { "orange","FF8000" }, { "pink","FF69B4" }
};

static void CrosshairCommand_Execute(const cc_string* args, int argsCount) {
	cc_uint8 rgb[3];
	cc_string hex;
	int i;

	if (argsCount >= 2 && String_CaselessEqualsConst(&args[0], "color")) {
		hex = args[1];
		for (i = 0; i < (int)Array_Elems(crosshair_colors); i++) {
			if (String_CaselessEqualsConst(&args[1], crosshair_colors[i].name)) hex = String_FromReadonly(crosshair_colors[i].hex);
		}
		if (!PackedCol_TryParseHex(&hex, rgb)) {
			Chat_AddRaw("&e/client crosshair: &cColor no valido. Usa un nombre o hex (ej: FF8000).");
			return;
		}
		Gui_CrosshairColor = PackedCol_Make(rgb[0], rgb[1], rgb[2], 255);
		Options_Set(OPT_CROSSHAIR_COLOR, &hex);
		Gui_LayoutAll();
		Chat_AddRaw("&e/client crosshair: &fColor cambiado.");
		return;
	}

	if (argsCount >= 2 && String_CaselessEqualsConst(&args[0], "size")) {
		float scale;
		if (!Convert_ParseFloat(&args[1], &scale) || scale < 0.25f || scale > 5.0f) {
			Chat_AddRaw("&e/client crosshair: &cEl tamano va de 0.25 a 5.");
			return;
		}
		Gui.RawCrosshairScale = scale;
		Options_Set(OPT_CROSSHAIR_SCALE, &args[1]);
		Gui_LayoutAll();
		Chat_AddRaw("&e/client crosshair: &fTamano cambiado.");
		return;
	}

	if (argsCount >= 1 && String_CaselessEqualsConst(&args[0], "reset")) {
		Gui_CrosshairColor    = PACKEDCOL_WHITE;
		Gui.RawCrosshairScale = 1.0f;
		Options_Set(OPT_CROSSHAIR_COLOR, NULL);
		Options_Set(OPT_CROSSHAIR_SCALE, NULL);
		Gui_LayoutAll();
		Chat_AddRaw("&e/client crosshair: &fMira restablecida.");
		return;
	}

	Chat_AddRaw("&e/client crosshair: &cUsa &fcolor [x]&c, &fsize [x] &co &freset&c.");
}

static struct ChatCommand CrosshairCommand = {
	"Crosshair", CrosshairCommand_Execute,
	0,
	{
		"&a/client crosshair color [nombre/hex]",
		"&a/client crosshair size [0.25-5]",
		"&a/client crosshair reset",
		"&eColores: white red green blue yellow cyan magenta orange pink",
	}
};

/*########################################################################################################################*
*-------------------------------------------------Classic98 commands (part 2)---------------------------------------------*
*#########################################################################################################################*/
static void Args_Join(const cc_string* args, int from, int count, cc_string* dst) {
	int i;
	for (i = from; i < count; i++) {
		if (i > from) String_Append(dst, ' ');
		String_AppendString(dst, &args[i]);
	}
}

static void Duration_Format(cc_string* dst, int secs) {
	int h = secs / 3600, m = (secs / 60) % 60, s = secs % 60;
	String_Format3(dst, "%i:%p2:%p2", &h, &m, &s);
}

/*------------------------------------------------------- timer ------------------------------------------------------------*/
static cc_bool timer_active, sw_active;
static double  timer_end, sw_start;

static void Timer_Tick(struct ScheduledTask* task) {
	if (!timer_active || Game.Time < timer_end) return;
	timer_active = false;
	Chat_AddRaw("&e[Timer] &aTiempo terminado!");
}

/* Parses 90, 90s, 5m, 1h, 1h30m, 2m30s. Returns -1 if invalid */
static int Duration_Parse(const cc_string* str) {
	int i, total = 0, cur = 0;
	cc_bool digits = false, any = false;

	for (i = 0; i < str->length; i++) {
		char c = str->buffer[i];
		if (c >= '0' && c <= '9') {
			cur = cur * 10 + (c - '0'); digits = true;
			if (cur > 1000000) return -1;
		} else if (digits && (c == 's' || c == 'S')) {
			total += cur;        cur = 0; digits = false; any = true;
		} else if (digits && (c == 'm' || c == 'M')) {
			total += cur * 60;   cur = 0; digits = false; any = true;
		} else if (digits && (c == 'h' || c == 'H')) {
			total += cur * 3600; cur = 0; digits = false; any = true;
		} else {
			return -1;
		}
	}
	if (digits) { total += cur; any = true; }
	return any ? total : -1;
}

static void TimerCommand_Execute(const cc_string* args, int argsCount) {
	char buf[STRING_SIZE];
	cc_string str = String_FromArray(buf);
	int secs;

	if (!argsCount || String_CaselessEqualsConst(&args[0], "status")) {
		if (!timer_active) { Chat_AddRaw("&e[Timer] &fNo hay ningun temporizador activo."); return; }
		secs = (int)(timer_end - Game.Time) + 1;
		if (secs < 0) secs = 0;
		Duration_Format(&str, secs);
		Chat_Add1("&e[Timer] &fFaltan &a%s", &str);
		return;
	}
	if (String_CaselessEqualsConst(&args[0], "stop")) {
		timer_active = false;
		Chat_AddRaw("&e[Timer] &fTemporizador cancelado.");
		return;
	}

	secs = Duration_Parse(&args[0]);
	if (secs < 1 || secs > 86400) {
		Chat_AddRaw("&e[Timer] &cUsa segundos o un formato como 5m, 1h30m, 2m30s (maximo 24h).");
		return;
	}
	timer_end    = Game.Time + secs;
	timer_active = true;
	Duration_Format(&str, secs);
	Chat_Add1("&e[Timer] &fTemporizador de &a%s &finiciado.", &str);
}

static struct ChatCommand TimerCommand = {
	"Timer", TimerCommand_Execute,
	0,
	{
		"&a/client timer [tiempo]  &e(90, 5m, 1h30m, 2m30s)",
		"&a/client timer status  &e/  &a/client timer stop",
		"&eTe avisa en el chat cuando termina el tiempo.",
	}
};

static void StopwatchCommand_Execute(const cc_string* args, int argsCount) {
	char buf[STRING_SIZE];
	cc_string str = String_FromArray(buf);
	int secs;

	if (argsCount && String_CaselessEqualsConst(&args[0], "start")) {
		sw_start  = Game.Time;
		sw_active = true;
		Chat_AddRaw("&e[Cronometro] &fIniciado.");
		return;
	}
	if (!sw_active) { Chat_AddRaw("&e[Cronometro] &fUsa &a/client stopwatch start &fpara iniciarlo."); return; }

	secs = (int)(Game.Time - sw_start);
	Duration_Format(&str, secs);
	if (argsCount && String_CaselessEqualsConst(&args[0], "stop")) {
		sw_active = false;
		Chat_Add1("&e[Cronometro] &fDetenido en &a%s", &str);
	} else {
		Chat_Add1("&e[Cronometro] &fLlevas &a%s", &str);
	}
}

static struct ChatCommand StopwatchCommand = {
	"Stopwatch", StopwatchCommand_Execute,
	0,
	{
		"&a/client stopwatch start  &e/  &a/client stopwatch stop",
		"&eSin argumentos muestra el tiempo que lleva corriendo.",
	}
};

/*------------------------------------------------------- ignore -----------------------------------------------------------*/
static void ChatFilterCommand_List(int kind, const char* title, const char* empty) {
	int i, count = ChatFilter_Count(kind);
	if (!count) { Chat_AddRaw(empty); return; }
	Chat_AddRaw(title);
	for (i = 0; i < count; i++) {
		cc_string w = ChatFilter_Get(kind, i);
		Chat_Add1("  &f%s", &w);
	}
}

static void IgnoreCommand_Execute(const cc_string* args, int argsCount) {
	int r;
	if (!argsCount || String_CaselessEqualsConst(&args[0], "list")) {
		ChatFilterCommand_List(CHAT_FILTER_IGNORE, "&e/client ignore: &fJugadores ignorados:", "&e/client ignore: &fNo ignoras a nadie.");
		return;
	}
	if (String_CaselessEqualsConst(&args[0], "remove")) {
		if (argsCount < 2 || !ChatFilter_Remove(CHAT_FILTER_IGNORE, &args[1])) {
			Chat_AddRaw("&e/client ignore: &cEse jugador no esta en tu lista.");
		} else {
			Chat_Add1("&e/client ignore: &fYa no ignoras a &a%s&f.", &args[1]);
		}
		return;
	}

	if (String_CaselessEquals(&args[0], &Game_Username)) {
		Chat_AddRaw("&e/client ignore: &cNo puedes ignorarte a ti mismo.");
		return;
	}
	r = ChatFilter_Add(CHAT_FILTER_IGNORE, &args[0]);
	if (r == 1)      Chat_AddRaw("&e/client ignore: &cNombre no valido.");
	else if (r == 2) Chat_AddRaw("&e/client ignore: &cYa ignoras a 16 jugadores, quita alguno.");
	else if (r == 3) Chat_AddRaw("&e/client ignore: &cYa ignoras a ese jugador.");
	else             Chat_Add1("&e/client ignore: &fAhora ignoras a &c%s&f.", &args[0]);
}

static struct ChatCommand IgnoreCommand = {
	"Ignore", IgnoreCommand_Execute,
	0,
	{
		"&a/client ignore [jugador]",
		"&a/client ignore list  &e/  &a/client ignore remove [jugador]",
		"&eOculta en tu pantalla los mensajes de ese jugador.",
		"&eSolo cambia lo que ves tu, el servidor no se entera.",
	}
};

/*----------------------------------------------------- highlight ----------------------------------------------------------*/
static void HighlightCommand_Execute(const cc_string* args, int argsCount) {
	int r;
	if (!argsCount || String_CaselessEqualsConst(&args[0], "list")) {
		ChatFilterCommand_List(CHAT_FILTER_HIGHLIGHT, "&e/client highlight: &fPalabras resaltadas:", "&e/client highlight: &fNo tienes palabras resaltadas.");
		Chat_Add1("&e/client highlight: &fResaltar tu nombre: %c", Chat_HighlightMe ? "&aactivado" : "&cdesactivado");
		return;
	}
	if (String_CaselessEqualsConst(&args[0], "me")) {
		if (argsCount < 2 || !(String_CaselessEqualsConst(&args[1], "on") || String_CaselessEqualsConst(&args[1], "off"))) {
			Chat_AddRaw("&e/client highlight: &cUsa &f/client highlight me on &co &foff&c.");
			return;
		}
		Chat_HighlightMe = String_CaselessEqualsConst(&args[1], "on");
		Options_SetBool(OPT_HIGHLIGHT_ME, Chat_HighlightMe);
		Chat_Add1("&e/client highlight: &fResaltar tu nombre: %c", Chat_HighlightMe ? "&aactivado" : "&cdesactivado");
		return;
	}
	if (String_CaselessEqualsConst(&args[0], "remove")) {
		if (argsCount < 2 || !ChatFilter_Remove(CHAT_FILTER_HIGHLIGHT, &args[1])) {
			Chat_AddRaw("&e/client highlight: &cEsa palabra no esta en tu lista.");
		} else {
			Chat_AddRaw("&e/client highlight: &fPalabra quitada.");
		}
		return;
	}

	r = ChatFilter_Add(CHAT_FILTER_HIGHLIGHT, &args[0]);
	if (r == 1)      Chat_AddRaw("&e/client highlight: &cPalabra no valida (2 a 31 letras, sin espacios).");
	else if (r == 2) Chat_AddRaw("&e/client highlight: &cYa tienes 16 palabras, quita alguna.");
	else if (r == 3) Chat_AddRaw("&e/client highlight: &cEsa palabra ya esta en la lista.");
	else             Chat_Add1("&e/client highlight: &fAhora se resalta &6%s&f.", &args[0]);
}

static struct ChatCommand HighlightCommand = {
	"Highlight", HighlightCommand_Execute,
	0,
	{
		"&a/client highlight [palabra]",
		"&a/client highlight list  &e/  &a/client highlight remove [palabra]",
		"&a/client highlight me on/off",
		"&eResalta en naranja esa palabra (y tu nombre) en el chat.",
	}
};

/*-------------------------------------------------------- alias -----------------------------------------------------------*/
#define ALIAS_MAX 16
#define ALIAS_NAME 16
#define ALIAS_TEXT 60
static char alias_name_chars[ALIAS_MAX][ALIAS_NAME];
static char alias_text_chars[ALIAS_MAX][ALIAS_TEXT + 1];
static int  alias_name_len[ALIAS_MAX], alias_text_len[ALIAS_MAX];
static int  alias_count;
static cc_bool alias_loaded, alias_running;

static cc_string Alias_Name(int i) { return String_Init(alias_name_chars[i], alias_name_len[i], ALIAS_NAME); }
static cc_string Alias_Text(int i) { return String_Init(alias_text_chars[i], alias_text_len[i], ALIAS_TEXT + 1); }

static void Alias_Save(void) {
	int i;
	for (i = 0; i < ALIAS_MAX; i++) {
		char key[32], buf[96];
		cc_string k = String_FromArray(key), v = String_FromArray(buf);
		cc_string n, t;
		String_Format1(&k, "classic98-alias-%i", &i);

		if (i < alias_count) {
			n = Alias_Name(i); t = Alias_Text(i);
			String_Format2(&v, "%s|%s", &n, &t);
			Options_Set(key, &v);
		} else {
			Options_Set(key, NULL);
		}
	}
}

static void Alias_LoadAll(void) {
	int i;
	if (alias_loaded) return;
	alias_loaded = true;

	for (i = 0; i < ALIAS_MAX; i++) {
		char key[32];
		cc_string k = String_FromArray(key), v, name, text;
		String_Format1(&k, "classic98-alias-%i", &i);
		if (!Options_UNSAFE_Get(key, &v)) break;

		String_UNSAFE_Separate(&v, '|', &name, &text);
		if (!name.length || name.length >= ALIAS_NAME || !text.length || text.length > ALIAS_TEXT) continue;

		Mem_Copy(alias_name_chars[alias_count], name.buffer, name.length);
		Mem_Copy(alias_text_chars[alias_count], text.buffer, text.length);
		alias_name_len[alias_count] = name.length;
		alias_text_len[alias_count] = text.length;
		alias_count++;
	}
}

static int Alias_Find(const cc_string* name) {
	int i;
	for (i = 0; i < alias_count; i++) {
		cc_string n = Alias_Name(i);
		if (String_CaselessEquals(&n, name)) return i;
	}
	return -1;
}

static cc_bool Alias_TryRun(const cc_string* name) {
	cc_string text;
	int i;
	if (alias_running) return false;
	Alias_LoadAll();

	i = Alias_Find(name);
	if (i < 0) return false;

	text = Alias_Text(i);
	alias_running = true;
	Chat_Send(&text, false);
	alias_running = false;
	return true;
}

static cc_bool Alias_IsBuiltin(const cc_string* name) {
	struct ChatCommand* cmd;
	for (cmd = cmds_head; cmd; cmd = cmd->next)
	{
		cc_string n = String_FromReadonly(cmd->name);
		if (String_CaselessEquals(&n, name)) return true;
	}
	return false;
}

static void AliasCommand_Execute(const cc_string* args, int argsCount) {
	char buf[STRING_SIZE];
	cc_string text = String_FromArray(buf);
	int i, j;
	Alias_LoadAll();

	if (argsCount >= 3 && String_CaselessEqualsConst(&args[0], "set")) {
		const cc_string* name = &args[1];
		if (name->length >= ALIAS_NAME) { Chat_AddRaw("&e/client alias: &cNombre demasiado largo (maximo 15)."); return; }
		for (j = 0; j < name->length; j++) {
			char c = name->buffer[j];
			if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_')) {
				Chat_AddRaw("&e/client alias: &cEl nombre solo puede tener letras, numeros y _");
				return;
			}
		}
		if (Alias_IsBuiltin(name)) { Chat_AddRaw("&e/client alias: &cEse nombre ya es un comando del cliente."); return; }

		Args_Join(args, 2, argsCount, &text);
		if (text.length > ALIAS_TEXT) { Chat_AddRaw("&e/client alias: &cTexto demasiado largo (maximo 60)."); return; }

		i = Alias_Find(name);
		if (i < 0) {
			if (alias_count >= ALIAS_MAX) { Chat_AddRaw("&e/client alias: &cYa tienes 16 atajos, borra alguno."); return; }
			i = alias_count++;
		}
		Mem_Copy(alias_name_chars[i], name->buffer, name->length);
		Mem_Copy(alias_text_chars[i], text.buffer, text.length);
		alias_name_len[i] = name->length;
		alias_text_len[i] = text.length;
		Alias_Save();
		Chat_Add1("&e/client alias: &fAtajo guardado. Usa &a/client %s", name);
		return;
	}

	if (argsCount >= 2 && String_CaselessEqualsConst(&args[0], "remove")) {
		i = Alias_Find(&args[1]);
		if (i < 0) { Chat_AddRaw("&e/client alias: &cEse atajo no existe."); return; }
		for (; i < alias_count - 1; i++) {
			Mem_Copy(alias_name_chars[i], alias_name_chars[i + 1], ALIAS_NAME);
			Mem_Copy(alias_text_chars[i], alias_text_chars[i + 1], ALIAS_TEXT + 1);
			alias_name_len[i] = alias_name_len[i + 1];
			alias_text_len[i] = alias_text_len[i + 1];
		}
		alias_count--;
		Alias_Save();
		Chat_AddRaw("&e/client alias: &fAtajo borrado.");
		return;
	}

	if (!argsCount || String_CaselessEqualsConst(&args[0], "list")) {
		if (!alias_count) { Chat_AddRaw("&e/client alias: &fNo tienes atajos."); return; }
		for (i = 0; i < alias_count; i++) {
			cc_string n = Alias_Name(i), t = Alias_Text(i);
			Chat_Add2("&a%s &f-> &e%s", &n, &t);
		}
		return;
	}
	Chat_AddRaw("&e/client alias: &cUsa &fset [nombre] [texto]&c, &flist &co &fremove [nombre]&c.");
}

static struct ChatCommand AliasCommand = {
	"Alias", AliasCommand_Execute,
	0,
	{
		"&a/client alias set [nombre] [texto]",
		"&a/client alias list  &e/  &a/client alias remove [nombre]",
		"&eEjemplo: &f/client alias set gg buen juego",
		"&eLuego &f/client gg &eenvia ese texto al chat.",
		"&eEl texto puede ser un comando del servidor, ej: /goto lobby",
	}
};

/*------------------------------------------------------- notes ------------------------------------------------------------*/
#define NOTES_MAX 20
#define NOTE_LEN 60
static char note_chars[NOTES_MAX][NOTE_LEN + 1];
static int  note_lens[NOTES_MAX];
static int  note_count;
static cc_bool notes_loaded;

static void Notes_Save(void) {
	int i;
	for (i = 0; i < NOTES_MAX; i++) {
		char key[32];
		cc_string k = String_FromArray(key), v;
		String_Format1(&k, "classic98-note-%i", &i);
		if (i < note_count) {
			v = String_Init(note_chars[i], note_lens[i], NOTE_LEN + 1);
			Options_Set(key, &v);
		} else {
			Options_Set(key, NULL);
		}
	}
}

static void Notes_Load(void) {
	int i;
	if (notes_loaded) return;
	notes_loaded = true;

	for (i = 0; i < NOTES_MAX; i++) {
		char key[32];
		cc_string k = String_FromArray(key), v;
		String_Format1(&k, "classic98-note-%i", &i);
		if (!Options_UNSAFE_Get(key, &v)) break;
		if (!v.length || v.length > NOTE_LEN) continue;

		Mem_Copy(note_chars[note_count], v.buffer, v.length);
		note_lens[note_count] = v.length;
		note_count++;
	}
}

static void NotesCommand_Execute(const cc_string* args, int argsCount) {
	char buf[STRING_SIZE];
	cc_string text = String_FromArray(buf);
	int i, n;
	Notes_Load();

	if (argsCount >= 2 && String_CaselessEqualsConst(&args[0], "add")) {
		Args_Join(args, 1, argsCount, &text);
		if (text.length > NOTE_LEN) { Chat_AddRaw("&e/client notes: &cNota demasiado larga (maximo 60)."); return; }
		if (note_count >= NOTES_MAX) { Chat_AddRaw("&e/client notes: &cYa tienes 20 notas, borra alguna."); return; }

		Mem_Copy(note_chars[note_count], text.buffer, text.length);
		note_lens[note_count] = text.length;
		note_count++;
		Notes_Save();
		Chat_Add1("&e/client notes: &fNota &a#%i &fguardada.", &note_count);
		return;
	}

	if (argsCount >= 2 && String_CaselessEqualsConst(&args[0], "remove")) {
		if (!Convert_ParseInt(&args[1], &n) || n < 1 || n > note_count) {
			Chat_AddRaw("&e/client notes: &cUsa el numero de la nota, mira &f/client notes list&c.");
			return;
		}
		for (i = n - 1; i < note_count - 1; i++) {
			Mem_Copy(note_chars[i], note_chars[i + 1], NOTE_LEN + 1);
			note_lens[i] = note_lens[i + 1];
		}
		note_count--;
		Notes_Save();
		Chat_AddRaw("&e/client notes: &fNota borrada.");
		return;
	}

	if (argsCount >= 1 && String_CaselessEqualsConst(&args[0], "clear")) {
		note_count = 0;
		Notes_Save();
		Chat_AddRaw("&e/client notes: &fTodas las notas fueron borradas.");
		return;
	}

	if (!argsCount || String_CaselessEqualsConst(&args[0], "list")) {
		if (!note_count) { Chat_AddRaw("&e/client notes: &fNo tienes notas."); return; }
		for (i = 0; i < note_count; i++) {
			cc_string t = String_Init(note_chars[i], note_lens[i], NOTE_LEN + 1);
			n = i + 1;
			Chat_Add2("&e%i. &f%s", &n, &t);
		}
		return;
	}
	Chat_AddRaw("&e/client notes: &cUsa &fadd [texto]&c, &flist&c, &fremove [numero] &co &fclear&c.");
}

static struct ChatCommand NotesCommand = {
	"Notes", NotesCommand_Execute,
	0,
	{
		"&a/client notes add [texto]",
		"&a/client notes list  &e/  &a/client notes remove [numero]",
		"&a/client notes clear",
		"&eLibreta de notas rapidas (hasta 20). Se guardan en tu cliente.",
	}
};

/*------------------------------------------------------ lantern -----------------------------------------------------------*/
static void LanternCommand_Execute(const cc_string* args, int argsCount) {
	cc_bool on = !Lantern_Enabled;
	int v;

	if (argsCount && (String_CaselessEqualsConst(&args[0], "size") || String_CaselessEqualsConst(&args[0], "power"))) {
		cc_bool isSize = String_CaselessEqualsConst(&args[0], "size");
		if (argsCount < 2 || !Convert_ParseInt(&args[1], &v) || v < 1 || v > 5) {
			Chat_Add1("&e/client lantern: &cUsa &f/client lantern %c [1-5]&c.", isSize ? "size" : "power");
			return;
		}
		if (isSize) { Lantern_Size  = v; Options_SetInt(OPT_LANTERN_SIZE,  v); }
		else        { Lantern_Power = v; Options_SetInt(OPT_LANTERN_POWER, v); }
		Chat_Add2("&e/client lantern: &f%c ahora es &a%i&f.", isSize ? "Tamano" : "Intensidad", &v);
		return;
	}

	if (argsCount && String_CaselessEqualsConst(&args[0], "on"))  on = true;
	else if (argsCount && String_CaselessEqualsConst(&args[0], "off")) on = false;
	else if (argsCount) {
		Chat_AddRaw("&e/client lantern: &cUsa &fon&c, &foff&c, &fsize [1-5] &co &fpower [1-5]&c.");
		return;
	}

	Lantern_Enabled = on;
	Options_SetBool(OPT_LANTERN, on);
	Chat_Add1("&e/client lantern: &fLinterna %c&f.", on ? "&aactivada" : "&cdesactivada");
}

static struct ChatCommand LanternCommand = {
	"Lantern", LanternCommand_Execute,
	0,
	{
		"&a/client lantern [on/off]  &e(sin argumentos alterna)",
		"&a/client lantern size [1-5]  &e/  &a/client lantern power [1-5]",
		"&eResplandor calido amarillo/naranja centrado en tu vista.",
		"&eEs un efecto visual: no cambia la iluminacion real del mapa.",
	}
};

static void ResolutionCommand_Execute(const cc_string* args, int argsCount) {
	int width, height;
	if (argsCount < 2) {
		Chat_Add4("&e/client: &fLa resolucion actual es %i@%f2 x %i@%f2", 
				&Window_Main.Width, &DisplayInfo.ScaleX, &Window_Main.Height, &DisplayInfo.ScaleY);
	} else if (!Convert_ParseInt(&args[0], &width) || !Convert_ParseInt(&args[1], &height)) {
		Chat_AddRaw("&e/client: &cEl ancho y el alto deben ser numeros enteros.");
	} else if (width <= 0 || height <= 0) {
		Chat_AddRaw("&e/client: &cEl ancho y el alto deben ser mayores que 0.");
	} else {
		Window_SetSize(width, height);
		/* Window_Create uses these, but scales by DPI. Hence DPI unscale them here. */
		Options_SetInt(OPT_WINDOW_WIDTH,  (int)(width  / DisplayInfo.ScaleX));
		Options_SetInt(OPT_WINDOW_HEIGHT, (int)(height / DisplayInfo.ScaleY));
	}
}

static struct ChatCommand ResolutionCommand = {
	"Resolution", ResolutionCommand_Execute,
	0,
	{
		"&a/client resolution [width] [height]",
		"&eFija con precision el tamano de la ventana.",
	}
};

static void ModelCommand_Execute(const cc_string* args, int argsCount) {
	if (argsCount) {
		Entity_SetModel(&Entities.CurPlayer->Base, args);
	} else {
		Chat_AddRaw("&e/client model: &cNo indicaste el nombre de un modelo.");
	}
}

static struct ChatCommand ModelCommand = {
	"Model", ModelCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY | COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client model [name]",
		"&bnames: &echibi, chicken, creeper, human, pig, sheep",
		"&e       skeleton, spider, zombie, sit, <numerical block id>",
	}
};

static void SkinCommand_Execute(const cc_string* args, int argsCount) {
	if (argsCount) {
		Entity_SetSkin(&Entities.CurPlayer->Base, args);
	} else {
		Chat_AddRaw("&e/client skin: &cNo indicaste el nombre de una skin.");
	}
}

static struct ChatCommand SkinCommand = {
	"Skin", SkinCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY | COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client skin [name]",
		"&eCambia tu skin por la del jugador indicado",
		"&a/client skin [url]",
		"&eCambia la skin por una URL que apunte directo a un .PNG",
	}
};

static void ClearDeniedCommand_Execute(const cc_string* args, int argsCount) {
	int count = TextureUrls_ClearDenied();
	Chat_Add1("Se quitaron &e%i &fURLs de texturas rechazadas.", &count);
}

static struct ChatCommand ClearDeniedCommand = {
	"ClearDenied", ClearDeniedCommand_Execute,
	COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client cleardenied",
		"&eBorra la lista de URLs de texturas que rechazaste",
	}
};

static void MotdCommand_Execute(const cc_string* args, int argsCount) {
	if (Server.IsSinglePlayer) {
		Chat_AddRaw("&eEste comando solo se puede usar en multijugador.");
		return;
	}
	Chat_Add1("&eNombre: &f%s", &Server.Name);
	Chat_Add1("&eMOTD: &f%s", &Server.MOTD);
}

static struct ChatCommand MotdCommand = {
	"Motd", MotdCommand_Execute,
	COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client motd",
		"&eMuestra el nombre y el MOTD del servidor."
	}
};

/*#######################################################################################################################*
*-------------------------------------------------------PlaceCommand-----------------------------------------------------*
*########################################################################################################################*/

static void PlaceCommand_Execute(const cc_string* args, int argsCount) {
	cc_string name;
	cc_uint8 off;
	int block;
	IVec3 pos;
	
	if (argsCount == 2) {
		Chat_AddRaw("&eFaltan argumentos.");
		return;
	}
	
	block = !argsCount || argsCount == 3 ? Inventory_SelectedBlock : Block_Parse(&args[0]);
	
	if (block == -1) {
		Chat_AddRaw("&eNo se pudo leer el bloque.");
		return;
	}
	if (block > Game_Version.MaxCoreBlock && !Block_IsCustomDefined(block)) {
		Chat_Add1("&eNo existe un bloque con id \"%i\".", &block); 
		return;
	}
	
	if (argsCount > 2) {
		off = argsCount == 4;
		if (!Convert_ParseInt(&args[0 + off], &pos.x) || !Convert_ParseInt(&args[1 + off], &pos.y) || !Convert_ParseInt(&args[2 + off], &pos.z)) {
			Chat_AddRaw("&eNo se pudieron leer las coordenadas.");
			return;
		}
	} else {
		IVec3_Floor(&pos, &Entities.CurPlayer->Base.Position);
	}
	
	if (!World_Contains(pos.x, pos.y, pos.z)) {
		Chat_AddRaw("&eLas coordenadas estan fuera de los limites del mundo.");
		return;
	}
	
	Game_ChangeBlock(pos.x, pos.y, pos.z, block);
	name = Block_UNSAFE_GetName(block);
	Chat_Add4("&eBloque %s colocado en (%i, %i, %i).", &name, &pos.x, &pos.y, &pos.z);
}

static struct ChatCommand PlaceCommand = {
	"Place", PlaceCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY,
	{
		"&a/client place [block] [x y z]",
		"&eColoca un bloque en [x y z].",
		"&eSi no indicas bloque, se usa el que llevas en la mano.",
		"&eSi no indicas coordenadas, se usan",
		"&e las coordenadas actuales."
	}
};

/*########################################################################################################################*
*-------------------------------------------------------DrawOpCommand-----------------------------------------------------*
*#########################################################################################################################*/
static IVec3 drawOp_mark1, drawOp_mark2;
static cc_bool drawOp_persist, drawOp_hooked, drawOp_hasMark1;
static const char* drawOp_name;
static void (*drawOp_Func)(IVec3 min, IVec3 max);

static void DrawOpCommand_BlockChanged(void* obj, IVec3 coords, BlockID old, BlockID now);
static void DrawOpCommand_ResetState(void) {
	if (drawOp_hooked) {
		Event_Unregister_(&UserEvents.BlockChanged, NULL, DrawOpCommand_BlockChanged);
		drawOp_hooked = false;
	}

	drawOp_hasMark1 = false;
}

static void DrawOpCommand_Begin(void) {
	cc_string msg; char msgBuffer[STRING_SIZE];
	String_InitArray(msg, msgBuffer);

	String_Format1(&msg, "&e%c: &fColoca o borra un bloque.", drawOp_name);
	Chat_AddOf(&msg, MSG_TYPE_CLIENTSTATUS_1);

	Event_Register_(&UserEvents.BlockChanged, NULL, DrawOpCommand_BlockChanged);
	drawOp_hooked = true;
}


static void DrawOpCommand_Execute(void) {
	IVec3 min, max;

	IVec3_Min(&min, &drawOp_mark1, &drawOp_mark2);
	IVec3_Max(&max, &drawOp_mark1, &drawOp_mark2);
	if (!World_Contains(min.x, min.y, min.z)) return;
	if (!World_Contains(max.x, max.y, max.z)) return;

	drawOp_Func(min, max);
}

static void DrawOpCommand_BlockChanged(void* obj, IVec3 coords, BlockID old, BlockID now) {
	cc_string msg; char msgBuffer[STRING_SIZE];
	String_InitArray(msg, msgBuffer);
	Game_UpdateBlock(coords.x, coords.y, coords.z, old);

	if (!drawOp_hasMark1) {
		drawOp_mark1    = coords;
		drawOp_hasMark1 = true;

		String_Format4(&msg, "&e%c: &fMarca 1 colocada en (%i, %i, %i), coloca la marca 2.", 
						drawOp_name, &coords.x, &coords.y, &coords.z);
		Chat_AddOf(&msg, MSG_TYPE_CLIENTSTATUS_1);
	} else {
		drawOp_mark2 = coords;

		DrawOpCommand_Execute();
		DrawOpCommand_ResetState();

		if (!drawOp_persist) {			
			Chat_AddOf(&String_Empty, MSG_TYPE_CLIENTSTATUS_1);
		} else {
			DrawOpCommand_Begin();
		}
	}
}

static const cc_string yes_string = String_FromConst("yes");
static void DrawOpCommand_ExtractPersistArg(cc_string* value) {
	drawOp_persist = false;
	if (!String_CaselessEnds(value, &yes_string)) return;

	drawOp_persist = true; 
	value->length  -= 3;
	String_UNSAFE_TrimEnd(value);
}

static int DrawOpCommand_ParseBlock(const cc_string* arg) {
	int block = Block_Parse(arg);

	if (block == -1) {
		Chat_Add2("&e%c: &c\"%s\" no es un nombre ni un id de bloque valido.", drawOp_name, arg); 
		return -1;
	}

	if (block > Game_Version.MaxCoreBlock && !Block_IsCustomDefined(block)) {
		Chat_Add2("&e%c: &cNo existe un bloque con id \"%s\".", drawOp_name, arg); 
		return -1;
	}
	return block;
}


/*########################################################################################################################*
*-------------------------------------------------------CuboidCommand-----------------------------------------------------*
*#########################################################################################################################*/
static int cuboid_block;

static void CuboidCommand_Draw(IVec3 min, IVec3 max) {
	BlockID toPlace;
	int x, y, z;

	toPlace = (BlockID)cuboid_block;
	if (cuboid_block == -1) toPlace = Inventory_SelectedBlock;

	for (y = min.y; y <= max.y; y++) {
		for (z = min.z; z <= max.z; z++) {
			for (x = min.x; x <= max.x; x++) {
				Game_ChangeBlock(x, y, z, toPlace);
			}
		}
	}
}

static void CuboidCommand_Execute(const cc_string* args, int argsCount) {
	cc_string value = *args;

	DrawOpCommand_ResetState();
	drawOp_name = "Cuboid";
	drawOp_Func = CuboidCommand_Draw;

	DrawOpCommand_ExtractPersistArg(&value);
	cuboid_block = -1; /* Default to cuboiding with currently held block */

	if (value.length) {
		cuboid_block = DrawOpCommand_ParseBlock(&value);
		if (cuboid_block == -1) return;
	}

	DrawOpCommand_Begin();
}

static struct ChatCommand CuboidCommand = {
	"Cuboid", CuboidCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY | COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client cuboid [block] [persist]",
		"&eRellena con [block] el prisma entre dos puntos.",
		"&eSi no indicas bloque, usa el que llevas en la mano.",
		"&e  Si indicas persist y es \"yes\", el comando",
		"&e  se repetira sin tener que escribirlo de nuevo.",
	}
};


/*########################################################################################################################*
*-------------------------------------------------------ReplaceCommand-----------------------------------------------------*
*#########################################################################################################################*/
static int replace_source, replace_target;

static void ReplaceCommand_Draw(IVec3 min, IVec3 max) {
	BlockID cur, source, toPlace;
	int x, y, z;

	source  = (BlockID)replace_source;
	toPlace = (BlockID)replace_target;
	if (replace_target == -1) toPlace = Inventory_SelectedBlock;

	for (y = min.y; y <= max.y; y++) {
		for (z = min.z; z <= max.z; z++) {
			for (x = min.x; x <= max.x; x++) {
				cur = World_GetBlock(x, y, z);
				if (cur != source) continue;
				Game_ChangeBlock(x, y, z, toPlace);
			}
		}
	}
}

static void ReplaceCommand_Execute(const cc_string* args, int argsCount) {
	cc_string value = *args;
	cc_string parts[2];
	int count;

	DrawOpCommand_ResetState();
	drawOp_name = "Replace";
	drawOp_Func = ReplaceCommand_Draw;

	DrawOpCommand_ExtractPersistArg(&value);
	replace_target = -1; /* Default to replacing with currently held block */

	if (!value.length) {
		Chat_AddRaw("&eReplace: &cSe requiere al menos un argumento"); return;
	}
	count = String_UNSAFE_Split(&value, ' ', parts, 2);

	replace_source = DrawOpCommand_ParseBlock(&parts[0]);
	if (replace_source == -1) return;

	if (count > 1) {
		replace_target = DrawOpCommand_ParseBlock(&parts[1]);
		if (replace_target == -1) return;
	}

	DrawOpCommand_Begin();
}

static struct ChatCommand ReplaceCommand = {
	"Replace", ReplaceCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY | COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client replace [source] [replacement] [persist]",
		"&eReemplaza todos los bloques [source] entre dos puntos por [replacement].",
		"&eSi no indicas [replacement], usa el bloque que llevas en la mano.",
		"&e  Si indicas persist y es \"yes\", el comando",
		"&e  se repetira sin tener que escribirlo de nuevo.",
	}
};


/*########################################################################################################################*
*------------------------------------------------------TeleportCommand----------------------------------------------------*
*#########################################################################################################################*/
static void TeleportCommand_Execute(const cc_string* args, int argsCount) {
	struct Entity* e = &Entities.CurPlayer->Base;
	struct LocationUpdate update;
	Vec3 v;

	if (argsCount != 3) {
		Chat_AddRaw("&e/client teleport: &cNo indicaste las coordenadas X, Y y Z.");
		return;
	}
	if (!Convert_ParseFloat(&args[0], &v.x) || !Convert_ParseFloat(&args[1], &v.y) || !Convert_ParseFloat(&args[2], &v.z)) {
		Chat_AddRaw("&e/client teleport: &cLas coordenadas deben ser numeros decimales");
		return;
	}

	update.flags = LU_HAS_POS;
	update.pos   = v;
	e->VTABLE->SetLocation(e, &update);
}

static struct ChatCommand TeleportCommand = {
	"TP", TeleportCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY,
	{
		"&a/client tp [x y z]",
		"&eTe mueve a las coordenadas indicadas.",
	}
};


/*########################################################################################################################*
*------------------------------------------------------BlockEditCommand----------------------------------------------------*
*#########################################################################################################################*/
static cc_bool BlockEditCommand_GetInt(const cc_string* str, const char* name, int* value, int min, int max) {
	if (!Convert_ParseInt(str, value)) {
		Chat_Add1("&eBlockEdit: &e%c debe ser un numero entero", name);
		return false;
	}

	if (*value < min || *value > max) {
		Chat_Add3("&eBlockEdit: &e%c debe estar entre %i y %i", name, &min, &max);
		return false;
	}
	return true;
}

static cc_bool BlockEditCommand_GetTexture(const cc_string* str, int* tex) {
	return BlockEditCommand_GetInt(str, "Texture", tex, 0, ATLAS1D_MAX_ATLASES - 1);
}

static cc_bool BlockEditCommand_GetCoords(const cc_string* str, Vec3* coords) {
	cc_string parts[3];
	IVec3 xyz;

	int numParts = String_UNSAFE_Split(str, ' ', parts, 3);
	if (numParts != 3) {
		Chat_AddRaw("&eBlockEdit: &cSe requieren 3 valores para una coordenada (X Y Z)");
		return false;
	}

	if (!BlockEditCommand_GetInt(&parts[0], "Coord. X", &xyz.x, -127, 127)) return false;
	if (!BlockEditCommand_GetInt(&parts[1], "Coord. Y", &xyz.y, -127, 127)) return false;
	if (!BlockEditCommand_GetInt(&parts[2], "Coord. Z", &xyz.z, -127, 127)) return false;

	coords->x = xyz.x / 16.0f;
	coords->y = xyz.y / 16.0f;
	coords->z = xyz.z / 16.0f;
	return true;
}

static cc_bool BlockEditCommand_GetBool(const cc_string* str, const char* name, cc_bool* value) {
	if (String_CaselessEqualsConst(str, "true") || String_CaselessEqualsConst(str, "yes")) {
		*value = true;
		return true;
	}

	if (String_CaselessEqualsConst(str, "false") || String_CaselessEqualsConst(str, "no")) {
		*value = false;
		return true;
	}

	Chat_Add1("&eBlockEdit: &e%c debe ser &ayes &eo &ano", name);
	return false;
}


static void BlockEditCommand_Execute(const cc_string* args, int argsCount__) {
	cc_string parts[3];
	cc_string* prop;
	cc_string* value;
	int argsCount, block, v;
	cc_bool b;
	Vec3 coords;

	if (String_CaselessEqualsConst(args, "properties")) {
		Chat_AddRaw("&ePropiedades de bloque editables:");
		Chat_AddRaw("&a  name &e- Fija el nombre del bloque");
		Chat_AddRaw("&a  all &e- Fija la textura de las seis caras del bloque");
		Chat_AddRaw("&a  sides &e- Fija la textura de las cuatro caras laterales");
		Chat_AddRaw("&a  left/right/front/back/top/bottom &e- Fija una sola textura");
		Chat_AddRaw("&a  collide &e- Fija el modo de colision del bloque");
		Chat_AddRaw("&a  drawmode &e- Fija el modo de dibujado del bloque");
		Chat_AddRaw("&a  min/max &e- Fija las esquinas minima/maxima del bloque");
		Chat_AddRaw("&eVe &a/client blockedit properties 2 &epara mas propiedades");
		return;
	}
	if (String_CaselessEqualsConst(args, "properties 2")) {
		Chat_AddRaw("&ePropiedades de bloque editables (pagina 2):");
		Chat_AddRaw("&a  walksound &e- Fija el sonido de pisada del bloque");
		Chat_AddRaw("&a  breaksound &e- Fija el sonido al romper el bloque");
		Chat_AddRaw("&a  fullbright &e- Fija si el bloque esta totalmente iluminado");
		Chat_AddRaw("&a  blockslight &e- Fija si el bloque bloquea la luz");
		return;
	}

	argsCount = String_UNSAFE_Split(args, ' ', parts, 3);
	if (argsCount < 3) {
		Chat_AddRaw("&eBlockEdit: &eSe requieren tres argumentos &e(Ve &a/client help blockedit&e)");
		return;
	}

	block = Block_Parse(&parts[0]);
	if (block == -1) {
		Chat_Add1("&eBlockEdit: &c\"%s\" no es un nombre ni un ID de bloque valido", &parts[0]);
		return;
	}

	/* TODO: Redo as an array */
	prop  = &parts[1];
	value = &parts[2];
	if (String_CaselessEqualsConst(prop, "name")) {
		Block_SetName(block, value);
	} else if (String_CaselessEqualsConst(prop, "all")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_SetSide(v, block);
		Block_Tex(block, FACE_YMAX) = v;
		Block_Tex(block, FACE_YMIN) = v;
	} else if (String_CaselessEqualsConst(prop, "sides")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_SetSide(v, block);
	} else if (String_CaselessEqualsConst(prop, "left")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_Tex(block, FACE_XMIN) = v;
	} else if (String_CaselessEqualsConst(prop, "right")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_Tex(block, FACE_XMAX) = v;
	} else if (String_CaselessEqualsConst(prop, "bottom")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_Tex(block, FACE_YMIN) = v;
	}  else if (String_CaselessEqualsConst(prop, "top")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_Tex(block, FACE_YMAX) = v;
	} else if (String_CaselessEqualsConst(prop, "front")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_Tex(block, FACE_ZMIN) = v;
	} else if (String_CaselessEqualsConst(prop, "back")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_Tex(block, FACE_ZMAX) = v;
	} else if (String_CaselessEqualsConst(prop, "collide")) {
		if (!BlockEditCommand_GetInt(value, "Modo de colision", &v, 0, COLLIDE_CLIMB)) return;

		Blocks.Collide[block] = v;
	} else if (String_CaselessEqualsConst(prop, "drawmode")) {
		if (!BlockEditCommand_GetInt(value, "Modo de dibujado", &v, 0, DRAW_SPRITE)) return;

		Blocks.Draw[block] = v;
	} else if (String_CaselessEqualsConst(prop, "min")) {
		if (!BlockEditCommand_GetCoords(value, &coords)) return;

		Blocks.MinBB[block] = coords;
	} else if (String_CaselessEqualsConst(prop, "max")) {
		if (!BlockEditCommand_GetCoords(value, &coords)) return;

		Blocks.MaxBB[block] = coords;
	} else if (String_CaselessEqualsConst(prop, "walksound")) {
		if (!BlockEditCommand_GetInt(value, "Sound", &v, 0, SOUND_COUNT - 1)) return;

		Blocks.StepSounds[block] = v;
	} else if (String_CaselessEqualsConst(prop, "breaksound")) {
		if (!BlockEditCommand_GetInt(value, "Sound", &v, 0, SOUND_COUNT - 1)) return;

		Blocks.DigSounds[block]  = v;
	} else if (String_CaselessEqualsConst(prop, "fullbright")) {
		if (!BlockEditCommand_GetBool(value, "Brillo total", &b))  return;
		//TODO: Fix this, brightness isn't just a bool anymore
		Blocks.Brightness[block] = b;
	} else if (String_CaselessEqualsConst(prop, "blockslight")) {
		if (!BlockEditCommand_GetBool(value, "Bloquea la luz", &b)) return;

		Blocks.BlocksLight[block] = b;
	} else {
		Chat_Add1("&eBlockEdit: &ePropiedad desconocida %s &e(Ve &a/client help blockedit&e)", prop);
		return;
	}

	Block_DefineCustom(block, false);
}

static struct ChatCommand BlockEditCommand = {
	"BlockEdit", BlockEditCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY | COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client blockedit [block] [property] [value]",
		"&eEdita la propiedad indicada del bloque indicado",
		"&a/client blockedit properties",
		"&eLista las propiedades de bloque editables",
	}
};


/*########################################################################################################################*
*------------------------------------------------------Commands component-------------------------------------------------*
*#########################################################################################################################*/
static void OnInit(void) {
	Commands_Register(&GpuInfoCommand);
	Commands_Register(&HelpCommand);
	Commands_Register(&RenderTypeCommand);
	Commands_Register(&ResolutionCommand);
	Commands_Register(&RetroCommand);
	Commands_Register(&TimerCommand);
	Commands_Register(&StopwatchCommand);
	Commands_Register(&IgnoreCommand);
	Commands_Register(&HighlightCommand);
	Commands_Register(&AliasCommand);
	Commands_Register(&NotesCommand);
	Commands_Register(&LanternCommand);
	ScheduledTask_Add(0.25, Timer_Tick);
	Commands_Register(&WhereCommand);
	Commands_Register(&WaypointCommand);
	Commands_Register(&FovCommand);
	Commands_Register(&ClearCommand);
	Commands_Register(&TimeCommand);
	Commands_Register(&CalcCommand);
	Commands_Register(&DiceCommand);
	Commands_Register(&CrosshairCommand);
	Commands_Register(&ModelCommand);
	Commands_Register(&SkinCommand);
	Commands_Register(&TeleportCommand);
	Commands_Register(&ClearDeniedCommand);
	Commands_Register(&MotdCommand);
	Commands_Register(&PlaceCommand);
	Commands_Register(&BlockEditCommand);
	Commands_Register(&CuboidCommand);
	Commands_Register(&ReplaceCommand);
}

static void OnFree(void) {
	cmds_head = NULL;
}

struct IGameComponent Commands_Component = {
	OnInit, /* Init  */
	OnFree  /* Free  */
};
