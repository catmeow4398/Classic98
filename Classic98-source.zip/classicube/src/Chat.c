#include "Chat.h"
#include "Commands.h"
#include "String_.h"
#include "Stream.h"
#include "Event.h"
#include "Game.h"
#include "Logger.h"
#include "Server.h"
#include "Funcs.h"
#include "Utils.h"
#include "Options.h"
#include "Drawer2D.h"
 
static char status[5][STRING_SIZE];
static char bottom[3][STRING_SIZE];
static char client[2][STRING_SIZE];
static char announcement[STRING_SIZE];
static char bigAnnouncement[STRING_SIZE];
static char smallAnnouncement[STRING_SIZE];

cc_string Chat_Status[5]       = { String_FromArray(status[0]), String_FromArray(status[1]), String_FromArray(status[2]),
                                                                String_FromArray(status[3]), String_FromArray(status[4]) };
cc_string Chat_BottomRight[3]  = { String_FromArray(bottom[0]), String_FromArray(bottom[1]), String_FromArray(bottom[2]) };
cc_string Chat_ClientStatus[2] = { String_FromArray(client[0]), String_FromArray(client[1]) };

cc_string Chat_Announcement = String_FromArray(announcement);
cc_string Chat_BigAnnouncement = String_FromArray(bigAnnouncement);
cc_string Chat_SmallAnnouncement = String_FromArray(smallAnnouncement);

float Chat_AnnouncementLeft;
float Chat_BigAnnouncementLeft;
float Chat_SmallAnnouncementLeft;

CC_BIG_VAR struct StringsBuffer Chat_Log, Chat_InputLog;
cc_bool Chat_Logging;

/*########################################################################################################################*
*-------------------------------------------------------Chat logging------------------------------------------------------*
*#########################################################################################################################*/
double Chat_RecentLogTimes[CHATLOG_TIME_MASK + 1];

static void ClearChatLogs(void) {
	Mem_Set(Chat_RecentLogTimes, 0, sizeof(Chat_RecentLogTimes));
	StringsBuffer_Clear(&Chat_Log);
}

static char      logNameBuffer[STRING_SIZE];
static cc_string logName = String_FromArray(logNameBuffer);
static char      logPathBuffer[FILENAME_SIZE];
static cc_string logPath = String_FromArray(logPathBuffer);

static struct Stream logStream;
static int lastLogDay, lastLogMonth, lastLogYear;

/* Resets log name to empty and resets last log date */
static void ResetLogFile(void) {
	logName.length = 0;
	lastLogYear    = -123;
}

/* Closes handle to the chat log file */
static void CloseLogFile(void) {
	cc_result res;
	if (!logStream.meta.file) return;

	res = logStream.Close(&logStream);
	if (res) { Logger_SysWarn2(res, "closing", &logPath); }
}

/* Whether the given character is an allowed in a log filename */
static cc_bool AllowedLogNameChar(char c) {
	return
		c == '{' || c == '}' || c == '[' || c == ']' || c == '(' || c == ')' ||
		(c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

void Chat_SetLogName(const cc_string* name) {
	char c;
	int i;
	if (logName.length) return;

	for (i = 0; i < name->length; i++) {
		c = name->buffer[i];

		if (AllowedLogNameChar(c)) {
			String_Append(&logName, c);
		} else if (c == '&') {
			i++; /* skip over following color code */
		}
	}
}

void Chat_DisableLogging(void) {
	Chat_Logging = false;
	lastLogYear  = -321;
	Chat_AddRaw("&cDesactivando el registro del chat");
	CloseLogFile();
}

static cc_bool CreateLogsDirectory(void) {
	static const cc_string dir = String_FromConst("logs");
	cc_filepath raw_dir;
	cc_result res;
	/* Utils_EnsureDirectory cannot be used here because it causes a stack overflow  */
	/* when running the game and an error occurs when trying to create the directory */
	/* This happens because when running the game, Logger_WarnFunc is changed to log */
	/* a message in chat instead of showing a dialog box, which causes the following */
	/* functions to be called in a recursive loop: */
	/*                                                                                         */
	/* Utils_EnsureDirectory --> Logger_IOWarn2 --> Chat_Add --> AppendChatLog -> OpenChatLog */
	/*  --> Utils_EnsureDirectory --> Logger_IOWarn2 --> Chat_Add --> AppendChatLog -> OpenChatLog */
	/*       --> Utils_EnsureDirectory --> Logger_IOWarn2 --> Chat_Add --> AppendChatLog -> OpenChatLog */
	/*            --> Utils_EnsureDirectory --> Logger_IOWarn2 --> Chat_Add --> AppendChatLog ... */
	/* and so on, until eventually the stack overflows */
	Platform_EncodePath(&raw_dir, &dir);
	res = Directory_Create2(&raw_dir);
	if (!res || res == ReturnCode_DirectoryExists) return true;

	Chat_DisableLogging();
	Logger_IOWarn2(res, "creating directory", &raw_dir); 
	return false;
}

static void OpenChatLog(struct cc_datetime* now) {
	cc_filepath raw_path;
	cc_result res;
	int i;
	if (Platform_ReadonlyFilesystem || !CreateLogsDirectory()) return;

	/* Ensure multiple instances do not end up overwriting each other's log entries. */
	for (i = 0; i < 20; i++) {
		logPath.length = 0;
		String_Format3(&logPath, "logs/%p4-%p2-%p2 ", &now->year, &now->month, &now->day);

		if (i > 0) {
			String_Format2(&logPath, "%s _%i.txt", &logName, &i);
		} else {
			String_Format1(&logPath, "%s.txt", &logName);
		}

		Platform_EncodePath(&raw_path, &logPath);
		res = Stream_AppendPath(&logStream, &raw_path);

		if (res && res != ReturnCode_FileShareViolation) {
			Chat_DisableLogging();
			Logger_IOWarn2(res, "appending to", &raw_path);
			return;
		}

		if (res == ReturnCode_FileShareViolation) continue;
		return;
	}

	Chat_DisableLogging();
	Chat_Add1("&cNo se pudo abrir el archivo de registro del chat tras %i intentos, me rindo", &i);	
}

static void AppendChatLog(const cc_string* text) {
	cc_string str; char strBuffer[DRAWER2D_MAX_TEXT_LENGTH];
	struct cc_datetime now;
	cc_result res;	

	if (!logName.length || !Chat_Logging) return;
	DateTime_CurrentLocal(&now);

	if (now.day != lastLogDay || now.month != lastLogMonth || now.year != lastLogYear) {
		CloseLogFile();
		OpenChatLog(&now);
	}

	lastLogDay = now.day; lastLogMonth = now.month; lastLogYear = now.year;
	if (!logStream.meta.file) return;

	/* [HH:mm:ss] text */
	String_InitArray(str, strBuffer);
	String_Format3(&str, "[%p2:%p2:%p2] ", &now.hour, &now.minute, &now.second);
	Drawer2D_WithoutColors(&str, text);

	res = Stream_WriteLine(&logStream, &str);
	if (!res) return;
	Chat_DisableLogging();
	Logger_SysWarn2(res, "writing to", &logPath);
}

void Chat_Add1(const char* format, const void* a1) {
	Chat_Add4(format, a1, NULL, NULL, NULL);
}
void Chat_Add2(const char* format, const void* a1, const void* a2) {
	Chat_Add4(format, a1, a2, NULL, NULL);
}
void Chat_Add3(const char* format, const void* a1, const void* a2, const void* a3) {
	Chat_Add4(format, a1, a2, a3, NULL);
}
void Chat_Add4(const char* format, const void* a1, const void* a2, const void* a3, const void* a4) {
	cc_string msg; char msgBuffer[STRING_SIZE * 2];
	String_InitArray(msg, msgBuffer);

	String_Format4(&msg, format, a1, a2, a3, a4);
	Chat_AddOf(&msg, MSG_TYPE_NORMAL);
}

void Chat_AddRaw(const char* raw) {
	cc_string str = String_FromReadonly(raw);
	Chat_AddOf(&str, MSG_TYPE_NORMAL);
}
void Chat_Add(const cc_string* text) { Chat_AddOf(text, MSG_TYPE_NORMAL); }

/*########################################################################################################################*
*----------------------------------------------------Classic98 chat filters-----------------------------------------------*
*#########################################################################################################################*/
static char filter_chars[2][CHAT_FILTER_MAX][CHAT_FILTER_LEN];
static int  filter_lens[2][CHAT_FILTER_MAX];
static int  filter_count[2];
static const char* const filter_keys[2] = { "classic98-ignore", "classic98-highlight" };
cc_bool Chat_HighlightMe = true;

int ChatFilter_Count(int kind) { return filter_count[kind]; }

cc_string ChatFilter_Get(int kind, int i) {
	return String_Init(filter_chars[kind][i], filter_lens[kind][i], CHAT_FILTER_LEN);
}

static char Filter_Lower(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + ' ') : c; }
static cc_bool Filter_IsWordChar(char c) {
	return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_';
}

static int Filter_Find(int kind, const cc_string* word) {
	int i, j;
	for (i = 0; i < filter_count[kind]; i++) {
		if (filter_lens[kind][i] != word->length) continue;
		for (j = 0; j < word->length; j++) {
			if (Filter_Lower(filter_chars[kind][i][j]) != Filter_Lower(word->buffer[j])) break;
		}
		if (j == word->length) return i;
	}
	return -1;
}

static void Filter_Save(int kind) {
	char buf[CHAT_FILTER_MAX * (CHAT_FILTER_LEN + 1)];
	cc_string str = String_FromArray(buf);
	int i;
	for (i = 0; i < filter_count[kind]; i++) {
		cc_string w = ChatFilter_Get(kind, i);
		if (i) String_Append(&str, ',');
		String_AppendString(&str, &w);
	}
	Options_Set(filter_keys[kind], str.length ? &str : NULL);
}

static void Filter_Load(int kind) {
	cc_string value, parts[CHAT_FILTER_MAX];
	int i, count;
	filter_count[kind] = 0;
	if (!Options_UNSAFE_Get(filter_keys[kind], &value)) return;

	count = String_UNSAFE_Split(&value, ',', parts, CHAT_FILTER_MAX);
	for (i = 0; i < count; i++) {
		if (!parts[i].length || parts[i].length >= CHAT_FILTER_LEN) continue;
		Mem_Copy(filter_chars[kind][filter_count[kind]], parts[i].buffer, parts[i].length);
		filter_lens[kind][filter_count[kind]] = parts[i].length;
		filter_count[kind]++;
	}
}

int ChatFilter_Add(int kind, const cc_string* word) {
	int i, minLen = (kind == CHAT_FILTER_IGNORE) ? 1 : 2;
	if (word->length < minLen || word->length >= CHAT_FILTER_LEN) return 1;
	for (i = 0; i < word->length; i++) {
		if (word->buffer[i] == ',' || word->buffer[i] == '&' || word->buffer[i] == ' ') return 1;
	}
	if (Filter_Find(kind, word) >= 0) return 3;
	if (filter_count[kind] >= CHAT_FILTER_MAX) return 2;

	i = filter_count[kind]++;
	Mem_Copy(filter_chars[kind][i], word->buffer, word->length);
	filter_lens[kind][i] = word->length;
	Filter_Save(kind);
	return 0;
}

cc_bool ChatFilter_Remove(int kind, const cc_string* word) {
	int i = Filter_Find(kind, word);
	if (i < 0) return false;

	for (; i < filter_count[kind] - 1; i++) {
		Mem_Copy(filter_chars[kind][i], filter_chars[kind][i + 1], CHAT_FILTER_LEN);
		filter_lens[kind][i] = filter_lens[kind][i + 1];
	}
	filter_count[kind]--;
	Filter_Save(kind);
	return true;
}

/* Copies text without colour codes (&x) */
static void Filter_StripColors(const cc_string* src, cc_string* dst) {
	int i;
	for (i = 0; i < src->length; i++) {
		if (src->buffer[i] == '&' && i + 1 < src->length) { i++; continue; }
		String_Append(dst, src->buffer[i]);
	}
}

/* Whether a message was written by an ignored player (their name appears before the first ':') */
static cc_bool Chat_IsIgnored(const cc_string* text) {
	char buf[DRAWER2D_MAX_TEXT_LENGTH + 4];
	cc_string plain = String_FromArray(buf), header;
	int colon, k, i, j;
	if (!filter_count[CHAT_FILTER_IGNORE]) return false;

	Filter_StripColors(text, &plain);
	colon = String_IndexOf(&plain, ':');
	if (colon < 0) return false;
	header = String_UNSAFE_Substring(&plain, 0, colon);

	for (k = 0; k < filter_count[CHAT_FILTER_IGNORE]; k++) {
		int len = filter_lens[CHAT_FILTER_IGNORE][k];
		for (i = 0; i + len <= header.length; i++) {
			for (j = 0; j < len; j++) {
				if (Filter_Lower(header.buffer[i + j]) != Filter_Lower(filter_chars[CHAT_FILTER_IGNORE][k][j])) break;
			}
			if (j < len) continue;
			if (i > 0 && Filter_IsWordChar(header.buffer[i - 1])) continue;
			if (i + len < header.length && Filter_IsWordChar(header.buffer[i + len])) continue;
			return true;
		}
	}
	return false;
}

/* Whether 'word' appears in 'text' at position i as a whole word (colour codes count as separators) */
static cc_bool Filter_MatchAt(const cc_string* text, int i, const char* word, int len) {
	int j;
	if (i + len > text->length) return false;
	for (j = 0; j < len; j++) {
		if (Filter_Lower(text->buffer[i + j]) != Filter_Lower(word[j])) return false;
	}
	if (i > 0 && Filter_IsWordChar(text->buffer[i - 1]) && !(i >= 2 && text->buffer[i - 2] == '&')) return false;
	if (i + len < text->length && Filter_IsWordChar(text->buffer[i + len])) return false;
	return true;
}

/* Wraps highlighted words in colour codes. Returns whether anything changed. */
static cc_bool Chat_Highlight(const cc_string* text, cc_string* out) {
	cc_bool changed = false;
	int bodyStart, i, k, len;

	if (!filter_count[CHAT_FILTER_HIGHLIGHT] && !(Chat_HighlightMe && Game_Username.length >= 2)) return false;
	bodyStart = String_IndexOf(text, ':');
	if (bodyStart < 0) bodyStart = 0;

	/* Don't highlight your own messages */
	for (i = 0; i < bodyStart && Game_Username.length; i++) {
		if (Filter_MatchAt(text, i, Game_Username.buffer, Game_Username.length)) return false;
	}

	for (i = 0; i < text->length; i++) {
		const char* hit = NULL;
		len = 0;

		if (i >= bodyStart) {
			for (k = 0; k < filter_count[CHAT_FILTER_HIGHLIGHT]; k++) {
				if (Filter_MatchAt(text, i, filter_chars[CHAT_FILTER_HIGHLIGHT][k], filter_lens[CHAT_FILTER_HIGHLIGHT][k])) {
					hit = filter_chars[CHAT_FILTER_HIGHLIGHT][k]; len = filter_lens[CHAT_FILTER_HIGHLIGHT][k];
					break;
				}
			}
			if (!hit && Chat_HighlightMe && Game_Username.length >= 2 && Filter_MatchAt(text, i, Game_Username.buffer, Game_Username.length)) {
				hit = Game_Username.buffer; len = Game_Username.length;
			}
		}

		if (hit) {
			String_AppendConst(out, "&6");
			for (k = 0; k < len; k++) String_Append(out, text->buffer[i + k]);
			String_AppendConst(out, "&f");
			i += len - 1;
			changed = true;
		} else {
			String_Append(out, text->buffer[i]);
		}
	}
	return changed;
}

static void Filters_Init(void) {
	Filter_Load(CHAT_FILTER_IGNORE);
	Filter_Load(CHAT_FILTER_HIGHLIGHT);
	Chat_HighlightMe = Options_GetBool(OPT_HIGHLIGHT_ME, true);
}

void Chat_AddOf(const cc_string* text, int msgType) {
	cc_string str;
	char hlBuf[DRAWER2D_MAX_TEXT_LENGTH * 2];
	cc_string hl = String_FromArray(hlBuf);

	if (msgType == MSG_TYPE_NORMAL) {
		if (Chat_IsIgnored(text)) return;
		if (Chat_Highlight(text, &hl)) text = &hl;

		/* Check for chat overflow (see issue #837) */
		/* This happens because Offset/Length are packed into a single 32 bit value, */
		/*  with 9 bits used for length. Hence if offset exceeds 2^23 (8388608), it */
		/*  overflows and earlier chat messages start wrongly appearing instead */
		if (Chat_Log.totalLength > 8388000) {
			ClearChatLogs();
			Chat_AddRaw("&cRegistro del chat borrado por llegar al limite de 8,3 millones de caracteres");
		}

		/* StringsBuffer_Add will abort game if try to add string > 511 characters */
		str        = *text; 
		str.length = min(str.length, DRAWER2D_MAX_TEXT_LENGTH);

		Chat_GetLogTime(Chat_Log.count) = Game.Time;
		AppendChatLog(&str);
		StringsBuffer_Add(&Chat_Log, &str);
	} else if (msgType >= MSG_TYPE_STATUS_1 && msgType <= MSG_TYPE_STATUS_3) {
		/* Status[0] is for texture pack downloading message */
		/* Status[1] is for reduced performance mode message */
		String_Copy(&Chat_Status[2 + (msgType - MSG_TYPE_STATUS_1)], text);
	} else if (msgType >= MSG_TYPE_BOTTOMRIGHT_1 && msgType <= MSG_TYPE_BOTTOMRIGHT_3) {	
		String_Copy(&Chat_BottomRight[msgType - MSG_TYPE_BOTTOMRIGHT_1], text);
	} else if (msgType == MSG_TYPE_ANNOUNCEMENT) {
		String_Copy(&Chat_Announcement, text);
		Chat_AnnouncementLeft = 5.0f;
	} else if (msgType == MSG_TYPE_BIGANNOUNCEMENT) {
		String_Copy(&Chat_BigAnnouncement, text);
		Chat_BigAnnouncementLeft = 5.0f;
	} else if (msgType == MSG_TYPE_SMALLANNOUNCEMENT) {
		String_Copy(&Chat_SmallAnnouncement, text);
		Chat_SmallAnnouncementLeft = 5.0f;
	} else if (msgType >= MSG_TYPE_CLIENTSTATUS_1 && msgType <= MSG_TYPE_CLIENTSTATUS_2) {
		String_Copy(&Chat_ClientStatus[msgType - MSG_TYPE_CLIENTSTATUS_1], text);
	} else if (msgType >= MSG_TYPE_EXTRASTATUS_1 && msgType <= MSG_TYPE_EXTRASTATUS_2) {
		String_Copy(&Chat_Status[msgType - MSG_TYPE_EXTRASTATUS_1], text);
	} 

	Event_RaiseChat(&ChatEvents.ChatReceived, text, msgType);
}


/*########################################################################################################################*
*-------------------------------------------------------Generic chat------------------------------------------------------*
*#########################################################################################################################*/
static void LogInputUsage(const cc_string* text) {
	/* Simplify navigating through input history by not logging duplicate entries */
	if (Chat_InputLog.count) {
		int lastIndex  = Chat_InputLog.count - 1;
		cc_string last = StringsBuffer_UNSAFE_Get(&Chat_InputLog, lastIndex);

		if (String_Equals(text, &last)) return;
	}
	StringsBuffer_Add(&Chat_InputLog, text);
}

void Chat_Send(const cc_string* text, cc_bool logUsage) {
	if (!text->length) return;
	Event_RaiseChat(&ChatEvents.ChatSending, text, 0);
	if (logUsage) LogInputUsage(text);

	if (!Commands_Execute(text)) {
		Server.SendChat(text);
	}
}

static void OnInit(void) {
	Filters_Init();
#if defined CC_BUILD_MOBILE || defined CC_BUILD_WEB
	/* Better to not log chat by default on mobile/web, */
	/* since it's not easily visible to end users */
	Chat_Logging = Options_GetBool(OPT_CHAT_LOGGING, false);
#else
	Chat_Logging = Options_GetBool(OPT_CHAT_LOGGING, true);
#endif
}

static void ClearCPEMessages(void) {
	Chat_AddOf(&String_Empty, MSG_TYPE_ANNOUNCEMENT);
	Chat_AddOf(&String_Empty, MSG_TYPE_BIGANNOUNCEMENT);
	Chat_AddOf(&String_Empty, MSG_TYPE_SMALLANNOUNCEMENT);
	Chat_AddOf(&String_Empty, MSG_TYPE_STATUS_1);
	Chat_AddOf(&String_Empty, MSG_TYPE_STATUS_2);
	Chat_AddOf(&String_Empty, MSG_TYPE_STATUS_3);
	Chat_AddOf(&String_Empty, MSG_TYPE_BOTTOMRIGHT_1);
	Chat_AddOf(&String_Empty, MSG_TYPE_BOTTOMRIGHT_2);
	Chat_AddOf(&String_Empty, MSG_TYPE_BOTTOMRIGHT_3);
}

static void OnReset(void) {
	CloseLogFile();
	ResetLogFile();
	ClearCPEMessages();
}

static void OnFree(void) {
	CloseLogFile();
	ClearCPEMessages();

	ClearChatLogs();
	StringsBuffer_Clear(&Chat_InputLog);
}

struct IGameComponent Chat_Component = {
	OnInit, /* Init  */
	OnFree, /* Free  */
	OnReset /* Reset */
};
